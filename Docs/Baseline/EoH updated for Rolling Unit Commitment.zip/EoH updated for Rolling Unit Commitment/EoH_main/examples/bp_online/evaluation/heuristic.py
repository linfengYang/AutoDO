# example heuristic
# replace it with your own heuristic designed by EoH

def score(item, bins):
    scores = item - bins
    return scores