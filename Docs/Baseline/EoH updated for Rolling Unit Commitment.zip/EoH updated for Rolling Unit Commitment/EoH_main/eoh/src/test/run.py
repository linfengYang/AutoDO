### Test Only ###
# Set system path

import sys
import os
ABS_PATH = os.path.dirname(os.path.abspath(__file__))
ROOT_PATH = os.path.join(ABS_PATH, "..", "..")
sys.path.append(ROOT_PATH)  # This is for finding all the modules
sys.path.append(ABS_PATH)



'''
ABS_PATH = os.path.dirname(os.path.abspath(__file__))
ROOT_PATH = os.path.join(ABS_PATH, "../..", "..")
sys.path.append(ROOT_PATH)  # This is for finding all the modules
sys.path.append(ABS_PATH)
print(ABS_PATH)

import os
import sys

# 获取项目根目录的绝对路径
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
sys.path.append(project_root)

#from ..eoh import eoh
#from ..eoh.utils.getParas import Paras
'''


from EoH_main.eoh.src.eoh import eoh
from EoH_main.eoh.src.eoh.utils.getParas import Paras
#from ..utils.getParas import Paras
#from evol.utils.createReport import ReportCreator


# Parameter initilization #
paras = Paras() 

# Set parameters #
paras.set_paras(method = "eoh",
                ec_operators  = ['e1','e2','m1','m2','m3'], # operators in EoH
                problem = "bp_online", # ['tsp_construct','bp_online','tsp_gls','fssp_gls']
                llm_api_endpoint = "api.deepseek.com", # set endpoint
                llm_api_key = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxx",   # set your key

                llm_model = "deepseek-reasoner", # 推理模型

                ec_pop_size = 10,        #种群大小
                ec_n_pop = 4,           #代数
                exp_n_proc = 10,        #处理器核数
                exp_debug_mode = False)

# paras.set_paras(method = "eoh",
#                 ec_operators  = ['e1','e2','m1','m2','m3'], # operators in EoH
#                 problem = "bp_online", # ['tsp_construct','bp_online','tsp_gls','fssp_gls']
#                 llm_api_endpoint = "api.chatanywhere.tech", # set endpoint
#                 llm_api_key = "sk-WIlasB8QB3Tbf2mgZ3P0wKu3cfjMMxL9ZAujbnyjHpEr6zhQ",   # set your key
#                 llm_model = "gpt-4o-mini", # set llm
#                 ec_pop_size = 20,      # number of samples in each population
#                 ec_n_pop = 20,
#                 exp_n_proc = 5,
#                 exp_debug_mode = False)
# paras.set_paras(method = "eoh",
#                 ec_operators  = ['e1','e2','m1','m2','m3'], # operators in EoH
#                 problem = "bp_online", # ['tsp_construct','bp_online','tsp_gls','fssp_gls']
#                 llm_api_endpoint = "api.suanli.cn", # set endpoint
#                 llm_api_key = "sk-vb9INwl7EbZU0UhtvzpgUDVqwDW2HjTtlazZrFc3LiNnDQlw",   # set your key
#                 llm_model = "deepseek-v3", # set llm
#                 ec_pop_size = 5,
#                 ec_n_pop = 20,
#                 exp_n_proc = 5,
#                 exp_debug_mode = False)




# EoH initilization
evolution = eoh.EVOL(paras)


# run EoH
evolution.run()

# Generate EoH Report
# RC = ReportCreator(paras)
# RC.generate_doc_report()




