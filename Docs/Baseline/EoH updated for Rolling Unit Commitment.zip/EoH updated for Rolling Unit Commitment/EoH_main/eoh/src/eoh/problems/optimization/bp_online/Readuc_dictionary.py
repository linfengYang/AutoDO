import sys
import types
import re
from . import ReadUC
import numpy as np
import time
import os
import json
import warnings
from joblib import Parallel, delayed




class UC_Data_dict:
    def __init__(self):
        self.N = None
        self.T = None
        self.PD = None
        self.invalid_data = []
        self.invalid_times = 0
        self.gap_power = 0
        self.plt_data = []
        # self.price_data = 0
        self.total_cost = 0
        self.units_info = []
        self.filename = None
        self.objective = 0

    def transform_to_dictionary(self, uc_data, filename, objective):
        self.filename = filename
        self.objective = objective
        self.N = uc_data.N
        self.T = uc_data.T
        self.PD = uc_data.PD
        for i in range(uc_data.N):
            self.units_info.append({
                          "a_i":uc_data.Alpha[i],
                           "b_i":uc_data.Beta[i] ,
                           "c_i":uc_data.Gamma[i],
                           "u_i": 0,
                           "p_i": 0,
                           "p_max_i": uc_data.Pmax[i],
                           "p_min_i": uc_data.Pmin[i],
                            "p_up_i": uc_data.Pup[i],
                            "p_down_i": uc_data.Pdown[i],
                            "p_start_i": uc_data.Pstart[i],
                            "p_shut_i": uc_data.Pshut[i],
                           "s_i": uc_data.CostHot[i],
                           "p_i_0": uc_data.P0[i],          #需要更新的信息
                           "u_i_0": uc_data.u0[i],          #需要更新的信息
                           "t_on_min_i": uc_data.MinTimeOn[i],
                           "t_off_min_i": uc_data.MinTimeOff[i],
                           "t_i_0": uc_data.T0[i],          #需要更新的信息  所有机组都需要更新

                           })



    def show_units_info(self):
        for i in self.units_info:
            print(i)


    def hard_constraint_check(self, schedules, period):
        invalid_units = []
        for i in range(len(self.units_info)):
            if self.units_info[i]['u_i_0'] == 0 and schedules[0][i] == 0:          #保持关机
                if self.units_info[i]['p_i_0'] == schedules[1][i] == 0:
                    continue
                else:
                    invalid_units.append(str(i)+"保持关机错误")
                    self.invalid_times += 1
                    continue
            elif self.units_info[i]['u_i_0'] == 0 and schedules[0][i] == 1:         #开机
                if schedules[1][i] == self.units_info[i]['p_start_i'] and abs(self.units_info[i]['t_i_0']) >= self.units_info[i]['t_off_min_i']:
                    continue
                else:
                    invalid_units.append(str(i)+"开机错误")
                    self.invalid_times += 1
                    continue
            elif self.units_info[i]['u_i_0'] == 1 and schedules[0][i] == 0:         #关机
                if self.units_info[i]['p_i_0'] == self.units_info[i]['p_shut_i'] and abs(self.units_info[i]['t_i_0']) >= self.units_info[i]['t_on_min_i']:
                    continue
                else:
                    invalid_units.append(str(i)+"关机错误")
                    self.invalid_times += 1
                    continue
            else:                                                                 #保持开机
                if self.units_info[i]['p_i_0'] <= schedules[1][i] and abs(
                        self.units_info[i]['p_i_0'] - schedules[1][i]) <= self.units_info[i]['p_up_i'] + 1e-6 and \
                        self.units_info[i]['p_min_i'] <= schedules[1][i] <= self.units_info[i]['p_max_i']:
                    continue
                if self.units_info[i]['p_i_0'] > schedules[1][i] and abs(
                        self.units_info[i]['p_i_0'] - schedules[1][i]) <= self.units_info[i]['p_down_i'] + 1e-6 and \
                        self.units_info[i]['p_min_i'] <= schedules[1][i] <= self.units_info[i]['p_max_i']:
                    continue
                else:
                    invalid_units.append(str(i)+"保持开机错误")
                    self.invalid_times += 1

        self.invalid_data.append(f"第{period}次：{', '.join(invalid_units)}")






############################
##########状态更新程序########
############################
    def update(self, schedules, load):
        for i in range(len(self.units_info)):
            if schedules[0, i] == 0 and self.units_info[i]['u_i_0'] == 0:    #保持关机
                self.units_info[i]['t_i_0'] -= 1
                self.units_info[i]['u_i_0'] = schedules[0, i]
                self.units_info[i]['p_i_0'] = schedules[1, i]
                continue
            elif schedules[0, i] == 1 and self.units_info[i]['u_i_0'] == 1:     #保持开机
                self.units_info[i]['t_i_0'] += 1
                self.units_info[i]['u_i_0'] = schedules[0, i]
                self.units_info[i]['p_i_0'] = schedules[1, i]
                self.total_cost += self.units_info[i]['a_i'] * 1 + self.units_info[i]['b_i'] * self.units_info[i]['p_i_0'] + self.units_info[i]['c_i'] * (self.units_info[i]['p_i_0'] ** 2)
                continue
            elif schedules[0, i] == 0 and self.units_info[i]['u_i_0'] == 1:     #关机
                self.units_info[i]['t_i_0'] = -1
                self.units_info[i]['u_i_0'] = schedules[0, i]
                self.units_info[i]['p_i_0'] = schedules[1, i]
            else:                                                               # 开机
                self.units_info[i]['t_i_0'] = 1
                self.units_info[i]['u_i_0'] = schedules[0, i]
                self.units_info[i]['p_i_0'] = schedules[1, i]
                self.total_cost += self.units_info[i]['a_i'] * 1 + self.units_info[i]['b_i'] * self.units_info[i]['p_i_0'] + self.units_info[i]['c_i'] * (self.units_info[i]['p_i_0'] ** 2) +self.units_info[i]['s_i']

        self.gap_power += abs(sum(schedules[1]) - load)
        self.plt_data.append(schedules[1])

    ############################
    ##########LLM测评程序########
    ############################
    def evaluate(self, code, name):
        try:
            # Suppress warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")

                # print("code_string:", code_string)
                # print(type(code_string))

                # Create a new module object
                heuristic_module = types.ModuleType("heuristic_module")

                # Execute the code string in the new module's namespace
                exec(code, heuristic_module.__dict__)

                # Add the module to sys.modules so it can be imported
                sys.modules[heuristic_module.__name__] = heuristic_module

                load = []
                for i in range(self.T):
                    load.append(self.PD[i])

                print(f"当前数据：{self.filename}")
                time_start = time.time()
                for i in range(self.T):
                    # print(f"第{i}次------------------------------------------------------------------------:")
                    if i + 1 < len(load):  # 检查i+1是否超出load长度
                        load_current = load[i:i + 2]
                    else:
                        load_current = load[i:] + [0]

                    # load_current = load[i]

                    # # schedules = heuristic_module.name(self.units_info, load_current)  # 调度算法
                    schedules = getattr(heuristic_module, name)(self.units_info,
                                                                load_current)  # 调度算法
                    # print(schedules, end=" ")
                    # print(sum(schedules[1]), sum(schedules[1]) - load[i])
                    self.hard_constraint_check(schedules, i)  # 硬约束检查
                    self.update(schedules, load[i])  # 更新状态（更新费用、更新负荷差距）
                time_end = time.time()
                time_cost = time_end - time_start

                # print(f"违反硬约束：{self.invalid_data}")
                print(f"违反硬约束数量：{self.invalid_times}")

                if self.invalid_times > 0:
                    return None  # 违反硬约束,说明算法不行 返回

                total = 0
                for i in range(self.T):
                    total += self.PD[i]

                real_power = [sum(sublist) for sublist in self.plt_data]
                gap_power = [abs(real_power[i] - load[i]) for i in range(self.T)]
                gap_power_rate = sum(gap_power) / total
                gap_price_rate = (abs(self.total_cost - self.objective) / self.objective)
                fitness = 0.5 * gap_power_rate + 0.5 * gap_price_rate  # 后续需要可以更改此权重

                # return [self.filename, self.total_cost, fitness, gap_power_rate, gap_price_rate, time_cost]          #测试需要
                return [fitness, gap_power_rate, gap_price_rate]  # 测试需要
                # return fitness                       #训练需要

        except Exception as e:
            print("Error:", str(e))
            return None


############################
##########LLM测评程序########
############################
def evaluate_Manger(name=None, algorithm=None, code=None, operator=None):
    print("正在评估算法...")

    json_file_path = '../DataSet/Training_set/gurobi_solve_data_for_training.json'  # 训练集路径
    with open(json_file_path, "r", encoding="utf-8") as file:
        training_set = json.load(file)

    # json_file_path = '../DataSet/Test_set/gurobi_solve_data_for_test.json'          #测试集路径
    # with open(json_file_path, "r", encoding="utf-8") as file:
    #     training_set = json.load(file)

    objects = []
    for training_data in training_set:
        # if training_data['data'] == "10_0_5_w.mod":                               #测试需要的补丁，训练时候注释掉
        #     continue

        file_path = '../DataSet/Training_set/' + training_data['data']  # 训练集路径
        # file_path = '../DataSet/Test_set/' + training_data['data']                #测试集路径
        # print(file_path)
        uc_data = ReadUC.UC_Data()
        uc_data = ReadUC.readUC(uc_data, file_path)
        uc_data_dict = UC_Data_dict()
        uc_data_dict.transform_to_dictionary(uc_data, training_data['data'],
                                             training_data['objective'])
        objects.append(uc_data_dict)

    warnings.filterwarnings("ignore", category=UserWarning)
    # fitness = Parallel(n_jobs=len(objects), timeout=600)(delayed(obj.evaluate)(code, name) for obj in objects)

    try:
        fitness = Parallel(n_jobs=1, timeout=600)(
            delayed(obj.evaluate)(code, name) for obj in objects)
    except TimeoutError:
        print("评估任务超时了")
        fitness = [None, None, None]

    fitness_list = []
    gap_power_rate_list = []
    gap_price_rate_list = []

    if None in fitness:
        history = {
            "name": name,
            "algorithm": algorithm,
            "code": code,
            "from": operator,
            "gap_power_rate": None,
            "gap_price_rate": None,
            "fitness": None,
        }
        name = get_unique_function_name(name)
        filename = "./results/history/" + str(name) + ".json"
        with open(filename, 'w') as f:
            json.dump(history, f, indent=5)
        return None

    if None not in fitness:
        for temp in fitness:
            if temp is not None:
                fitness_list.append(temp[0])  # 将需要的数据提取出来
                gap_power_rate_list.append(temp[1])
                gap_price_rate_list.append(temp[2])

        history = {
            "name": name,
            "algorithm": algorithm,
            "code": code,
            "from": operator,
            "gap_power_rate": np.mean(gap_power_rate_list),
            "gap_price_rate": np.mean(gap_price_rate_list),
            "fitness": np.mean(fitness_list),
        }

        name = get_unique_function_name(name)
        filename = "./results/history/" + str(name) + ".json"
        with open(filename, 'w') as f:
            json.dump(history, f, indent=5)

        # return fitness                  #测试使用
        # return np.mean(fitness)           #训练使用

        return np.mean(fitness_list)


def get_unique_function_name(base_name):
    # 读取已有的 json 文件名（去掉 .json 后缀）
    existing_names = {
        os.path.splitext(f)[0]
        for f in os.listdir("./results/history/")
        if f.endswith(".json")
    }

    # 如果不冲突，直接返回
    if base_name not in existing_names:
        return base_name

    # 冲突的话，加时间戳
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    return f"{base_name}_{timestamp}"












