import numpy as np
import importlib
from .get_instance import GetData
from .prompts import GetPrompts
import types
import warnings
import sys

from . import ReadUC
from . import Readuc_dictionary

class BPONLINE():
    def __init__(self):
        # self.uc_data = ReadUC.UC_Data()
        # # self.filename = r"D:\桌面\Postgraduate\研究生\程序\UC_AF\UC_AF\modify_5_std.mod"
        # self.filename = r"D:\桌面\Postgraduate\研究生\程序\10_std.mod"
        # self.uc_data = ReadUC.readUC(self.uc_data, self.filename)
        # self.uc_data_dict = Readuc_dictionary.UC_Data_dict(self.uc_data)

        # self.uc_data_dict.show_units_info()

        # getdate = GetData()
        # self.instances, self.lb = getdate.get_instances()             #datasets是五个数据的集合 lb是'Weibull 5k'的最优值
        # self.prompts = GetPrompts()                                   #prompts是提示信息的集合
        # self.instances = self.uc_data_dict.units_info

        # print("instances:", self.instances[0])
        # print("---------------------------------------------")

        self.prompts = GetPrompts()


    def get_valid_bin_indices(self,item: float, bins: np.ndarray) -> np.ndarray:
        """Returns indices of bins in which item can fit."""
        return np.nonzero((bins - item) >= 0)[0]


    def online_binpack(self,items, bins, alg):
        """Performs online binpacking of `items` into `bins`."""
        # Track which items are added to each bin.
        packing = [[] for _ in bins]
        # Add items to bins.
        n = 1
        for item in items:
            # Extract bins that have sufficient space to fit item.
            valid_bin_indices = self.get_valid_bin_indices(item, bins)
            # Score each bin based on heuristic.
            priorities = alg.score(item, bins[valid_bin_indices])         #切片子数组
            # Add item to bin with highest priority.
            best_bin = valid_bin_indices[np.argmax(priorities)]
            bins[best_bin] -= item
            packing[best_bin].append(item)
            n=n+1

        # Remove unused bins from packing.
        packing = [bin_items for bin_items in packing if bin_items]
        return packing, bins




 #    # @funsearch.run
 #    def evaluateGreedy(self,alg) -> float:
 #        # algorithm_module = importlib.import_module("ael_alg")
 #        # alg = importlib.reload(algorithm_module)
 #        """Evaluate heuristic function on a set of online binpacking instances."""
 #        # List storing number of bins used for each instance.
 #        #num_bins = []
 #        # Perform online binpacking for each instance.
 #        # for name in instances:
 #        #     #print(name)
 #
 # #---------------------重构代码到这里-------------------------------------------
 #        try:
 #            load = []
 #            for i in range(self.uc_data.T):
 #                load.append(self.uc_data.PD[i])
 #
 #            for i in range(self.uc_data.T):
 #                # print(f"第{i}次------------------------------------------------------------------------:")
 #                if i + 1 < len(load):  # 检查i+1是否超出load长度
 #                    load_current = load[i:i + 2]
 #                else:
 #                    load_current = load[i:] + [0]
 #                schedules = alg.schedule(self.uc_data_dict.units_info, load_current)  # 调度算法
 #                # print(schedules, end=" ")
 #                # print(sum(schedules[1]), sum(schedules[1]) - load[i])
 #                self.uc_data_dict.hard_constraint_check(schedules, i)  # 硬约束检查
 #                self.uc_data_dict.update(schedules, load[i])  # 更新状态（更新费用、更新负荷差距）
 #                # self.uc_data_dict.show_units_info()  # 显示状态
 #                # if i == 22:
 #                #     break
 #
 #            # print(f"违反硬约束：{self.uc_data_dict.invalid_data}")
 #
 #            if self.uc_data_dict.invalid_times > 0:
 #                return None                                # 违反硬约束,说明算法不行 返回
 #
 #            total = 0
 #            for i in range(self.uc_data.T):
 #                total += self.uc_data.PD[i]
 #
 #            real_power = [sum(sublist) for sublist in self.uc_data_dict.plt_data]
 #            gap_power = [abs(real_power[i] - load[i]) for i in range(self.uc_data.T)]
 #            gap_power_rate = sum(gap_power) / total
 #
 #
 #            if "5_std.mod" in self.filename:
 #                gap_price_rate = (abs(self.uc_data_dict.total_cost - 276849.1544) / 276849.1544)
 #                gap_rate = 0.5 * gap_power_rate + 0.5 * gap_price_rate
 #            if "8_std.mod" in self.filename:
 #                gap_price_rate = (abs(self.uc_data_dict.total_cost - 450471.3640424) / 450471.3640424)
 #                gap_rate = 0.5 * gap_power_rate + 0.5 * gap_price_rate
 #            if "10_std.mod" in self.filename:
 #                gap_price_rate = (abs(self.uc_data_dict.total_cost - 567626.2051995839) / 567626.2051995839)
 #                gap_rate = 0.5 * gap_power_rate + 0.5 * gap_price_rate
 #
 #
 #
 #            fitness = gap_rate
 #            return fitness
 #        except Exception as e:
 #            print("Error:", str(e))
 #            return None                         #这里考虑将错误信息返回 以便重新生成代码


    def evaluate(self, code_string):
        fitness = Readuc_dictionary.evaluate_Manger(name="schedule", algorithm=None, code=code_string, operator=None)
        return fitness








