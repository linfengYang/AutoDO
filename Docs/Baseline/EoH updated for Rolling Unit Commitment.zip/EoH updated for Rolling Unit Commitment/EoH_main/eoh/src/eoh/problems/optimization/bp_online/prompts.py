class GetPrompts():
    def __init__(self):
#         self.prompt_task = "I need help designing a novel score function that scoring a set of bins to assign an item. \
# In each step, the item will be assigned to the bin with the maximum score. If the rest capacity of a bin equals the maximum capacity, it will not be used. The final goal is to minimize the number of used bins."
#         self.prompt_func_name = "score"
#         self.prompt_func_inputs = ['item', 'bins']          #‘item’是单数  'bins'是数组
#         self.prompt_func_outputs = ['scores']                 #‘scores’是数组
#         self.prompt_inout_inf = "'item' and 'bins' are the size of current item and the rest capacities of feasible bins, which are larger than the item size. \
# The output named 'scores' is the scores for the bins for assignment. "
#         self.prompt_other_inf = "Note that 'item' is of type int, while 'bins' and 'scores' are both Numpy arrays. The novel function should be sufficiently complex in order to achieve better performance. It is important to ensure self-consistency."
# #Include the following imports at the beginning of the code: 'import numpy as np', and 'from numba import jit'. Place '@jit(nopython=True)' just above the 'priority' function definition."

        self.prompt_task = "I need help designing a novel heuristic to solve Rolling Unit Commitment Problem.In a rolling scheduling framework, the heuristic algorithm is executed at each time step to schedule a set of units that meet the current load demand.At each time step,the load can be allocated to a single unit or multiple units.The units must meet the following Physical Limitations:The output of each unit must be greater than or equal to its minimum output limit and less than or equal to its maximum output limit,and the units must satisfy the minimum up-time and minimum down-time limit、ramp up and ramp down limit、 startup and shutdown ramp limit.The final goal is to ensure that the total output of all units meets the current load as closely as possible while minimizing the total cost."
        self.prompt_func_name = "schedule"
        self.prompt_func_inputs = ['units_info', 'load']
        self.prompt_inputs_inf = "'units_info’ is a list where each element is a dictionary. Each dictionary represents the information of a single unit, with keys and values corresponding to the unit's attributes and their assigned values.‘load’ is a list of length 2 and the first element represents the current load to be allocated, while the second element indicates the forecasted load for the next time period."
        self.prompt_func_outputs = ['schedules']
        self.prompt_outputs_inf = "The output named‘schedules’ is a two-dimensional NumPy array, where the first row represents the u_i of the corresponding units, and the second row represents their respective load outputs p_i."
        self.prompt_other_inf = "Note that Each dictionary of ‘units_info’ include the following keys a_i, b_i, c_i, u_i, p_i,p_min_i,p_max_i,p_up_i,p_down_i,p_start_i,p_shut_i,t_on_min_i, t_off_min_i, s_i, u_i_0, t_i_0, p_i_0."
        self.prompt_nomenclature = "BELOW IS THE NOMENCLATURE:\
a_i, b_i, c_i represent the Coefficients of the quadratic production cost function of unit i.\
u_i represents the commitment state of unit i,the value is 1 only if it is allocated to the load,and the default value is 0.\
p_i represents the load that needs to be allocated to unit i, and the default value is 0.\
p_min_i, p_max_i represent the minimum and maximum power output of unit i.\
p_up_i,p_down_i represent the ramp up and ramp down limit of unit i.\
p_start_i represents the maximum output a unit can reach in the first available scheduling period after being started.\
p_shut_i represents the maximum output a unit can reach in the final scheduling period before being shut down.\
t_on_min_i represents the minimum up time of unit i.\
t_off_min_i represents the  minimum down time of unit i.\
s_i represents the startup cost of unit i, if the current unit is allocated a load and u_i_0 equals 0, s_i takes effect in the cost function.\
u_i_0 represents the previous commitment state of unit i.\
t_i_0 represents the number of periods unit  i has been online (+) or offline (-) before the current period.A unit i that was online in the previous period must remain online if it has not satisfied the minimum up time t_on_min_i or if its previous assigned load exceeds its shutdown capacity p_shut_i.\
p_i_0 represents the power output of unit i in previous time period.\
The total costs is the sum of the cost functions (a_i * u_i + b_i * p_i + c_i * p_i ** 2 + s_i) of all units."
        self.prompt_other_inf2 = "Avoid utilizing the random component, and it is crucial to maintain self-consistency. Do not give additional explanations."



    def get_task(self):
        return self.prompt_task
    
    def get_func_name(self):
        return self.prompt_func_name
    
    def get_func_inputs(self):
        return self.prompt_func_inputs

    def get_inputs_inf(self):
        return self.prompt_inputs_inf
    
    def get_func_outputs(self):
        return self.prompt_func_outputs

    def get_outputs_inf(self):
        return self.prompt_outputs_inf

    def get_other_inf(self):
        return self.prompt_other_inf

    def get_nomenclature(self):
        return self.prompt_nomenclature

    def get_other_inf2(self):
        return self.prompt_other_inf2

