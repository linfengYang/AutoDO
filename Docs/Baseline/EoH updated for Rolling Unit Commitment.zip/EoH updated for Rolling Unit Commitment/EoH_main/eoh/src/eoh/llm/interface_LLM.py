import json

from ..llm.api_general import InterfaceAPI
from ..llm.api_local_llm import InterfaceLocalLLM

class InterfaceLLM:
    def __init__(self, api_endpoint, api_key, model_LLM,llm_use_local,llm_local_url, debug_mode):
        self.api_endpoint = api_endpoint
        self.api_key = api_key
        self.model_LLM = model_LLM
        self.debug_mode = debug_mode
        self.llm_use_local = llm_use_local
        self.llm_local_url = llm_local_url

        print("- check LLM API")

        if self.llm_use_local:
            print('local llm delopyment is used ...')
            
            if self.llm_local_url == None or self.llm_local_url == 'xxx' :
                print(">> Stop with empty url for local llm !")
                exit()

            self.interface_llm = InterfaceLocalLLM(
                self.llm_local_url
            )

        else:
            print('remote llm api is used ...')

            if self.api_key == None or self.api_endpoint ==None or self.api_key == 'xxx' or self.api_endpoint == 'xxx':
                print(">> Stop with wrong API setting: Set api_endpoint (e.g., api.chat...) and api_key (e.g., kx-...) !")
                exit()

            self.interface_llm = InterfaceAPI(
                self.api_endpoint,
                self.api_key,
                self.model_LLM,
                self.debug_mode,
            )

            
        res = self.interface_llm.get_response("1+1=?")

        if res == None:
            print(">> Error in LLM API, wrong endpoint, key, model or local deployment!")
            exit()

        # choose LLMs
        # if self.type == "API2D-GPT":
        #     self.interface_llm = InterfaceAPI2D(self.key,self.model_LLM,self.debug_mode)
        # else:
        #     print(">>> Wrong LLM type, only API2D-GPT is available! \n")

    def get_response(self, prompt_content):
        response = self.interface_llm.get_response(prompt_content)
        return response

#
#         response = '''
# ### Heuristic Description
# {
# The heuristic is designed for rolling unit commitment with a focus on handling physical constraints and minimizing costs at each time step. The main steps are:
#
# 1. **Pre-commitment**: Determine forced on/off units based on minimum up/downtime, shutdown ramp constraints, and historical status.
# 2. **Base Commitment**: Form a base group of committed units including forced-on and initially free-on units.
# 3. **Adjust for Over/Undercapacity**:
#    - **Overcapacity (load < total min)**: Attempt to shut down free-on units if feasible (respecting ramp-down limits) to reduce the minimum output.
#    - **Undercapacity (load > total max)**: Commit free-off units sorted by average cost per MW at minimum output to meet the deficit.
# 4. **Economic Dispatch**: For committed units, minimize variable cost via marginal cost-based allocation while respecting ramp and output constraints.
# }
#
# ### Python Implementation
# ```python
# import numpy as np
#
# def schedule(units_info, load):
#     current_load = load[0]
#     num_units = len(units_info)
#     forced_on, forced_off, free_on, free_off = [], [], [], []
#
#     # Classify units into forced on/off or free on/off
#     for idx, unit in enumerate(units_info):
#         u_i0 = unit['u_i_0']
#         t_i0 = unit['t_i_0']
#         p_i0 = unit['p_i_0']
#         p_shut_i = unit['p_shut_i']
#         t_on_min_i = unit['t_on_min_i']
#         t_off_min_i = unit['t_off_min_i']
#
#         if u_i0 == 1:
#             if t_i0 < t_on_min_i or p_i0 > p_shut_i:
#                 forced_on.append(idx)
#             else:
#                 free_on.append(idx)
#         else:  # u_i0 = 0
#             if -t_i0 < t_off_min_i:
#                 forced_off.append(idx)
#             else:
#                 free_off.append(idx)
#
#     base_units = forced_on + free_on
#     shutdown_units = []
#
#     # Compute bounds for each unit type
#     L, U = {}, {}
#     for idx in base_units:
#         unit = units_info[idx]
#         p_min_i = unit['p_min_i']
#         p_max_i = unit['p_max_i']
#         p_i0 = unit['p_i_0']
#         p_down_i = unit['p_down_i']
#         p_up_i = unit['p_up_i']
#         L[idx] = max(p_min_i, p_i0 - p_down_i)
#         U[idx] = min(p_max_i, p_i0 + p_up_i)
#
#     for idx in free_off:
#         unit = units_info[idx]
#         p_min_i = unit['p_min_i']
#         p_max_i = unit['p_max_i']
#         p_start_i = unit['p_start_i']
#         L[idx] = p_min_i
#         U[idx] = min(p_max_i, p_start_i)
#
#     total_min_base = sum(L.get(idx, 0) for idx in base_units)
#     total_max_base = sum(U.get(idx, 0) for idx in base_units)
#
#     # Handle overcapacity (current_load < total_min_base)
#     if current_load < total_min_base:
#         candidates = []
#         for idx in free_on:
#             unit = units_info[idx]
#             p_i0 = unit['p_i_0']
#             p_down_i = unit['p_down_i']
#             if p_i0 <= p_down_i:  # Feasible shutdown
#                 saving = L[idx]
#                 candidates.append((saving, idx))
#         candidates.sort(key=lambda x: x[0], reverse=True)
#
#         over_capacity = total_min_base - current_load
#         shutdown_units = []
#         for saving, idx in candidates:
#             if over_capacity <= 0:
#                 break
#             shutdown_units.append(idx)
#             over_capacity -= saving
#             if idx in base_units:
#                 base_units.remove(idx)
#
#     # Handle undercapacity (current_load > total_max_base)
#     commit_units = []
#     if current_load > total_max_base:
#         candidates = []
#         for idx in free_off:
#             unit = units_info[idx]
#             a_i = unit['a_i']
#             b_i = unit['b_i']
#             c_i = unit['c_i']
#             s_i = unit['s_i']
#             min_i = L[idx]
#             cost_total = s_i + a_i + b_i * min_i + c_i * (min_i ** 2)
#             avg_cost = cost_total / min_i
#             added_capacity = U[idx]
#             candidates.append((avg_cost, added_capacity, idx))
#         candidates.sort(key=lambda x: x[0])
#
#         deficit = current_load - total_max_base
#         commit_units = []
#         for avg_cost, added_cap, idx in candidates:
#             if deficit <= 0:
#                 break
#             commit_units.append(idx)
#             deficit -= added_cap
#         base_units.extend(commit_units)
#
#     # Economic dispatch for committed units
#     L_vec, U_vec, b_vec, c_vec = [], [], [], []
#     base_indices = []
#     for idx in base_units:
#         base_indices.append(idx)
#         L_vec.append(L[idx])
#         U_vec.append(U[idx])
#         unit = units_info[idx]
#         b_vec.append(unit['b_i'])
#         c_vec.append(unit['c_i'])
#
#     n_base = len(base_indices)
#     p_vec = np.array(L_vec)  # Start at lower bounds
#     residual = current_load - np.sum(p_vec)
#
#     if residual > 0:  # Distribute residual to minimize cost
#         while residual > 1e-5:
#             mc = np.array(b_vec) + 2 * np.array(c_vec) * p_vec
#             headroom = np.array(U_vec) - p_vec
#             valid_indices = np.where(headroom > 1e-5)[0]
#             if valid_indices.size == 0:
#                 break
#             min_mc_idx = valid_indices[np.argmin(mc[valid_indices])]
#             alloc = min(residual, headroom[min_mc_idx])
#             p_vec[min_mc_idx] += alloc
#             residual -= alloc
#
#     # Prepare output schedules
#     schedules = np.zeros((2, num_units))
#     for i, idx in enumerate(base_indices):
#         schedules[0, idx] = 1
#         schedules[1, idx] = p_vec[i]
#
#     return schedules
# ```
# '''
#         return response
