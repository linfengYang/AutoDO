import numpy as np

def readUC(data_UC, pathAndFilename):
    with open(pathAndFilename) as obj:
        # 忽略第一行数据
        obj.readline()
        # 读取第2行数据
        temp = obj.readline()
        data_UC.T = int(temp.split()[1])   #HorizonLen 24时段
        # 读取第3行数据
        temp = obj.readline()
        data_UC.N = int(temp.split()[1])    #NumThermal 机组数
        # 忽悠4-10行数据
        for i in range(7):
            obj.readline()
        # 读取11行数据
        pd = obj.readline()
        # 将11行数据存入列表
        for each in pd.split():
            data_UC.PD.append(float(each))    #Loads 各个时段负荷
        # 忽略12行数据
        obj.readline()
        # 读取13行数据
        rt = obj.readline()
        # 将13行数据存入列表
        for each in rt.split():
            data_UC.Spin.append(float(each))   #Spin 各个时段备用负荷
        # 忽略14行数据
        obj.readline()
        # 读取机组参数
        unit_parameter = []
        for i in range(data_UC.N):
            temp = obj.readline()
            unit_parameter.append(temp.split())         #第十五行数据
            temp = obj.readline()
            data_UC.Pup.append(float(temp.split()[1]))        #16行爬坡约束
            data_UC.Pdown.append(float(temp.split()[2]))



        if "_std.mod" in pathAndFilename and len(unit_parameter[0]) == 17:
            data_UC.TimeCold = [float(i[16]) for i in unit_parameter]        #第17个参数为冷启动时间
        CostHotTemp = [float(i[13]) for i in unit_parameter]                # 14参数热启动费用
        # 初始化各参数
        data_UC.Alpha = [float(i[3]) for i in unit_parameter]  # 参数α       三个参数为费用
        data_UC.Beta = [float(i[2]) for i in unit_parameter]  # 参数β
        data_UC.Gamma = [float(i[1]) for i in unit_parameter]  # 参数γ
        data_UC.Pmax = [float(i[5]) for i in unit_parameter]  # 机组功率上界
        data_UC.Pmin = [float(i[4]) for i in unit_parameter]  # 机组功率下界
        data_UC.MinTimeOff = [float(i[8]) for i in unit_parameter]  # 最小停机时间
        data_UC.MinTimeOn = [float(i[7]) for i in unit_parameter]  # 最小开机时间
        data_UC.T0 = [float(i[6]) for i in unit_parameter]  #在T0之前已经开机或者关机的时间
        data_UC.P0 = [float(i[15]) for i in unit_parameter]  # 各机组功率初始状态
        # data_UC.Pstart = data_UC.Pmin                        #开关机能力
        # data_UC.Pshut = data_UC.Pmin
        data_UC.Pstart = [float(i[4]) for i in unit_parameter]
        data_UC.Pshut =[float(i[4]) for i in unit_parameter]
        data_UC.PD = np.array(data_UC.PD)                    #转为数字列表
        data_UC.Spin = np.array(data_UC.Spin)                #转为数字列表



        for i in data_UC.P0:
            if i != 0:
                data_UC.u0.append(1)
            else:
                data_UC.u0.append(0)

        if "_std.mod" in pathAndFilename:                 #不同机组的冷启动费用
            data_UC.CostCold = [i for i in CostHotTemp]  # 火电机组冷启动费用 - -N * 1矩阵
            if "5_std.mod" in pathAndFilename:
                data_UC.CostCold = CostHotTemp
        else:
            data_UC.TimeCold = [0] * data_UC.N


        data_UC.CostHot = CostHotTemp
        data_UC.StartCost = data_UC.CostHot
        data_UC.iframp = np.ones(data_UC.N)
        data_UC.CostFlag = np.ones(data_UC.N)


        return data_UC


class UC_Data:
    def __init__(self):
            self.T = 0  # 时段数
            self.N = 0  # 机组数
            self.PD = []  # 负荷
            self.Spin = []  # 备用负荷
            self.Pup = []  # 爬坡约束
            self.Pdown = []  # 跌坡约束
            self.TimeCold = []  # 冷启动时间
            self.CostCold = []  # 冷启动费用
            self.CostHot = []  # 热启动费用
            self.StartCost = []  # 初始费用
            self.Alpha = []  # 参数α
            self.Beta = []  # 参数β
            self.Gamma = []  # 参数γ
            self.Pmax = []  # 机组功率上界
            self.Pmin = []  # 机组功率下界
            self.MinTimeOff = []  # 最小停机时间
            self.MinTimeOn = []  # 最小开机时间
            self.T0 = []  # 在T0之前已经开机或者关机的时间
            self.P0 = []  # 各机组功率初始状态
            self.Pstart = []  # 开关机能力
            self.Pshut = []  # 停机能力
            self.u0 = []  # 初始状态
            self.iframp = []  # 是否有启动滑竿
            self.CostFlag = []  # 费用标志  1：有费用  0：无费用

    def print_class_attributes(self):
        """
        打印类的所有属性及其对应的注释。
        """
        attributes = {
            'T': '时段数',
            'N': '机组数',
            'PD': '负荷',
            'Spin': '备用负荷',
            'Pup': '爬坡约束',
            'Pdown': '跌坡约束',
            'TimeCold': '冷启动时间',
            'CostCold': '冷启动费用',
            'CostHot': '热启动费用',
            'StartCost': '初始费用',
            'Alpha': '参数α',
            'Beta': '参数β',
            'Gamma': '参数γ',
            'Pmax': '机组功率上界',
            'Pmin': '机组功率下界',
            'MinTimeOff': '最小停机时间',
            'MinTimeOn': '最小开机时间',
            'T0': '在T0之前已经开机或者关机的时间',
            'P0': '各机组功率初始状态',
            'Pstart': '开关机能力',
            'Pshut': '停机能力',
            'u0': '初始状态',
            'iframp': '是否有启动滑竿',
            'CostFlag': '费用标志  1：有费用  0：无费用'
        }

        for attr, comment in attributes.items():
            print(f"{attr}: {getattr(self, attr)}  # {comment}")












